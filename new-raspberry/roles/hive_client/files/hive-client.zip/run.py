#!/usr/bin/env python
# -*- coding: utf-8 -*-
from hive_client import app

app.run(debug=True)

if __name__ == "__main__":
    app.run()